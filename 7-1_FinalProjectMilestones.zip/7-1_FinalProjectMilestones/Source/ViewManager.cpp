///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// manage the viewing of 3D objects within the viewport - camera, projection
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f; 
	float gLastFrame = 0.0f;
	//declared initial mouse speed and sensitivity 
	float MovementSpeed = 2.5f;
	float MouseSensitivity = 0.1f;



	// the following variable is false when orthographic projection
	// is off and true when it is on
	bool bOrthographicProjection = false;
}
/************************************************************************
*	Method to adjust view based on changes in directions of camera
*
* The LookAt matrix matrix creates a view matrix for the three specified camera vectors:
*		camera position (Position)
*		target position (Front)
*		the up vector in world space (WorldUp)
*************************************************************************/

glm::mat4 GetViewMatrix() {
	return glm::lookAt(g_pCamera->Position, g_pCamera->Position + g_pCamera->Front, g_pCamera->Up);
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager *pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();
	// default camera view parameters
	g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
	g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->MovementSpeed = 20;

	// Declaring world coordinates
	g_pCamera->WorldUp = glm::vec3(0.0f, 1.0f, 0.0f);
	//g_pCamera->Right is perpendicular on Up and Front and calculated by the cross product (Up x Front)
	g_pCamera->Right = glm::normalize(glm::cross(g_pCamera->Up, g_pCamera->Front));

	// Revised zoom, speed, yaw, pitch, update
	g_pCamera->Zoom = 80.0f;
	g_pCamera->Yaw = -90.0f;
	g_pCamera->Pitch = 0.0f;
}
/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// tell GLFW to capture all mouse events
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// this callback is used to receive mouse moving events
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

	//this callback is used to receive mouse wheel scrolling events
		glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);

	// enable blending for supporting tranparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return(window);
}
/***********************************************************
 *  Mouse Scroll Callback Function
 *
 *	Adjusts the vertical scroll offset yoffset of camera travel around scene
 *  called automatically from GLFW whenever the mouse wheel scroll
 *	within the active GLFW display window.
 ***********************************************************/
void  ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double xoffset, double yoffset)
{
	// Adjust speed magnitude and restrict range of min/max speed to avoid overshooting
	MovementSpeed += yoffset * 0.5f;

	if (MovementSpeed < 0.1f) { MovementSpeed = 0.1f; }
	else if (MovementSpeed > 20.0f) { MovementSpeed = 20.0f; }
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	// when the first mouse move event is received, this needs to be recorded so that
	// all subsequent mouse moves can correctly calculate the X position offset and Y
	// position offset for proper operation
	if (gFirstMouse)
	{
		gLastX = xMousePos;
		gLastY = yMousePos;
		gFirstMouse = false;
	}

	// calculate the X offset and Y offset values for moving the 3D camera accordingly
	float xOffset = xMousePos - gLastX;
	float yOffset = gLastY - yMousePos; // reversed since y-coordinates go from bottom to top

	// set the current positions into the last position variables
	gLastX = xMousePos;
	gLastY = yMousePos;

	//=============================================
	/*
	* mouse sensitivity and Euler angles are added
	*/
	float MouseSensitivity = 0.1f;  // added
	xOffset *= MouseSensitivity;
	yOffset *= MouseSensitivity;

	// incrementing offset values of Euler angles to change orientation of scene
	g_pCamera->Yaw += xOffset;
	g_pCamera->Pitch += yOffset;

	// Constrain pitch to avoid screen flipping/lockups

	if (g_pCamera->Pitch > 89.0f)  g_pCamera->Pitch = 89.0f;
	if (g_pCamera->Pitch < -89.0f) g_pCamera->Pitch = -89.0f;

	// Update Front, Right and Up vectors using the updated Euler angles
	// updateCameraVectors();

	glm::vec3 direction;
	direction.x = cos(glm::radians(g_pCamera->Yaw)) * cos(glm::radians(g_pCamera->Pitch));
	direction.y = sin(glm::radians(g_pCamera->Pitch));
	direction.z = sin(glm::radians(g_pCamera->Yaw)) * cos(glm::radians(g_pCamera->Pitch));
	g_pCamera->Front = glm::normalize(direction);

	//=============================
	// move the 3D camera according to the calculated offsets
	g_pCamera->ProcessMouseMovement(xOffset, yOffset);
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  This method is called to process any keyboard events
 *  that may be waiting in the event queue.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
	{
		// close the window if the escape key has been pressed
		if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		{
			glfwSetWindowShouldClose(m_pWindow, true);
		}

		// if the camera object is null, then exit this method
		if (NULL == g_pCamera) { return; }
		/*	===================================================================
		*	WASD keys should be used to control the forward (zoom in), backward (zoom out),
		*	left, and (pan) right motion.
		* ===================================================================
		*/
		// Press key "W" moves scene forward
		if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
			{ g_pCamera->ProcessKeyboard(FORWARD, MovementSpeed * gDeltaTime);}
		// Press key "S" moves scene backward
		if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
			{g_pCamera->ProcessKeyboard(BACKWARD, MovementSpeed * gDeltaTime);}
		// Press key "A" moves scene to left
		if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
			{g_pCamera->ProcessKeyboard(LEFT, MovementSpeed * gDeltaTime);}
		// Press key "D" moves scene to right
		if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
			{g_pCamera->ProcessKeyboard(RIGHT, MovementSpeed * gDeltaTime);	}
		/*============================================================
		*	Adding QE keys to control the upward and downward movement
		* *============================================================
		*/
		// Press key "Q" moves scene downward
		if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
			{g_pCamera->ProcessKeyboard(DOWN, MovementSpeed * gDeltaTime);}
		// Press key "E" moves scene upward
		if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
			{g_pCamera->ProcessKeyboard(UP, MovementSpeed * gDeltaTime);}
		//switching views from orthographic to perspective
		if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
			{ bOrthographicProjection = true;}
		else if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS) 
			{bOrthographicProjection = false;}
	}
/***********************************************************
 *  PrepareSceneView()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// per-frame timing
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// process any keyboard events that may be waiting in the 
	// event queue
	ProcessKeyboardEvents();

	// get the current view matrix from the camera
	view = g_pCamera->GetViewMatrix();

	// Switch the projection function call based on state
	//**********************************************************************

	float aspectRatio = (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT;

	if (bOrthographicProjection)
	{
		// Perspective (Field of view, Aspect ratio, Near plane, Far plane)
		// define the current projection matrix
		projection = glm::perspective(glm::radians(g_pCamera->Zoom), aspectRatio, 0.1f, 100.0f);
	}
	else {
	 // Orthographic bounds (Left, Right, Bottom, Top, Near plane, Far plane)
	 // Scaling orthographic bounds by aspect ratio prevents 2D stretching
	 float orthoSize = 20.0f;
	 projection = glm::ortho(-orthoSize * aspectRatio, orthoSize * aspectRatio, -orthoSize, orthoSize, 0.1f, 100.0f);
	}
	//**********************************************************************
	// if the shader manager object is valid
	if (NULL != m_pShaderManager)
	{
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ViewName, view);
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		// set the view position of the camera into the shader for proper rendering
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}