///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
	const char* g_UseLightingName2 = "bActive";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection 

	for (int i = 0; i < 16; i++) {
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}

	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	// free up the allocated memory
	m_pShaderManager = NULL;
	if (NULL != m_basicMeshes)
	{
		delete m_basicMeshes;
		m_basicMeshes = NULL;
	}
	// destroy the created OpenGL textures
	DestroyGLTextures();

	// clear the collection of defined materials
	m_objectMaterials.clear();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3) {
			glPixelStorei(GL_UNPACK_ALIGNMENT, 1); // code added to 
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		}
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}
/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}
/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

 /***********************************************************
  *  LoadSceneTextures()
  *
  *  This method is used for preparing the 3D scene by loading
  *  the shapes, textures in memory to support the 3D scene
  *  rendering
  ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	/*** STUDENTS - add the code BELOW for loading the textures that ***/
	/*** will be used for mapping to objects in the 3D scene. Up to  ***/
	/*** 16 textures can be loaded per scene. Refer to the code in   ***/
	/*** the OpenGL Sample for help.                                 ***/

	bool bReturn = false;

	bReturn = CreateGLTexture("textures/barrelTexture.jpg", "barrel");
	bReturn = CreateGLTexture("textures/granite.jpg", "granite");
	bReturn = CreateGLTexture("textures/basketWaves.jpg", "basket");
	bReturn = CreateGLTexture("textures/fotoGranits.jpg", "tiled");
	bReturn = CreateGLTexture("textures/vintageWood.jpg", "vintage_wood");
	bReturn = CreateGLTexture("textures/whirlyWood.jpg", "whirl");
	bReturn = CreateGLTexture("textures/woodEnds.jpg", "wood_ends");
	bReturn = CreateGLTexture("textures/woodVertical.jpg", "vertical_wood");
	bReturn = CreateGLTexture("textures/rock.jpg", "rock");
	bReturn = CreateGLTexture("textures/sand.jpg", "sand");
	bReturn = CreateGLTexture("textures/ground.jpg", "ground");
	bReturn = CreateGLTexture("textures/concrete.jpg", "concrete");

	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

/***********************************************************
  *  DefineObjectMaterials()
  *
  *  This method is used for configuring the various material
  *  settings for all of the objects within the 3D scene.
  ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	/*** STUDENTS - add the code BELOW for defining object materials. ***/
	/*** There is no limit to the number of object materials that can ***/
	/*** be defined. Refer to the code in the OpenGL Sample for help  ***/
	{
		OBJECT_MATERIAL goldMaterial;
		goldMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.1f);
		goldMaterial.ambientStrength = 0.4f;
		goldMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.2f);
		goldMaterial.specularColor = glm::vec3(0.6f, 0.5f, 0.4f);
		goldMaterial.shininess = 22.0;
		goldMaterial.tag = "gold";

		m_objectMaterials.push_back(goldMaterial);

		OBJECT_MATERIAL cementMaterial;
		cementMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.2f);
		cementMaterial.ambientStrength = 0.2f;
		cementMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
		cementMaterial.specularColor = glm::vec3(0.4f, 0.4f, 0.4f);
		cementMaterial.shininess = 0.5;
		cementMaterial.tag = "cement";

		m_objectMaterials.push_back(cementMaterial);

		OBJECT_MATERIAL woodMaterial;
		woodMaterial.ambientColor = glm::vec3(0.4f, 0.3f, 0.1f);
		woodMaterial.ambientStrength = 0.2f;
		woodMaterial.diffuseColor = glm::vec3(0.3f, 0.2f, 0.1f);
		woodMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
		woodMaterial.shininess = 0.3;
	
		woodMaterial.tag = "wood";

		m_objectMaterials.push_back(woodMaterial);

		OBJECT_MATERIAL tileMaterial;
		tileMaterial.ambientColor = glm::vec3(0.2f, 0.3f, 0.4f);
		tileMaterial.ambientStrength = 0.3f;
		tileMaterial.diffuseColor = glm::vec3(0.3f, 0.2f, 0.1f);
		tileMaterial.specularColor = glm::vec3(0.4f, 0.5f, 0.6f);
		tileMaterial.shininess = 25.0;
		tileMaterial.tag = "tile";

		m_objectMaterials.push_back(tileMaterial);

		OBJECT_MATERIAL glassMaterial;
		glassMaterial.ambientColor = glm::vec3(0.4f, 0.4f, 0.4f);
		glassMaterial.ambientStrength = 0.3f;
		glassMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);
		glassMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);
		glassMaterial.shininess = 85.0;
		glassMaterial.tag = "glass";

		m_objectMaterials.push_back(glassMaterial);

		OBJECT_MATERIAL clayMaterial;
		clayMaterial.ambientColor = glm::vec3(0.2f, 0.2f, 0.3f);
		clayMaterial.ambientStrength = 0.3f;
		clayMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.5f);
		clayMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.4f);
		clayMaterial.shininess = 0.5;
		clayMaterial.tag = "clay";

		m_objectMaterials.push_back(clayMaterial);
	}
}
/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// this line of code is NEEDED for telling the shaders to render 
	// the 3D scene with custom lighting, if no light sources have
	// been added then the display window will be black - to use the 
	// default OpenGL lighting then comment out the following line
	//m_pShaderManager->setBoolValue(g_UseLightingName, true);

	/*** STUDENTS - add the code BELOW for setting up light sources ***/
	/*** Up to four light sources can be defined. Refer to the code ***/
	/*** in the OpenGL Sample for help                              ***/

	m_pShaderManager->setBoolValue("bUseLighting", true);
	
		// ----------- DIRECTIONAL LIGHT -----------
		// 
		// Direction from the light source pointing towards the scene
		m_pShaderManager->setBoolValue("directionalLight.bActive", true);

		m_pShaderManager->setVec3Value("directionalLight.direction", glm::normalize(glm::vec3(0.0f, -1.0f, -0.5f)));
		// Light color intensities are not normalized
		m_pShaderManager->setVec3Value("directionalLight.ambient", glm::vec3(0.6f, 0.6f, 0.6f)); 
		// Set a reasonable ambient minimum
		m_pShaderManager->setVec3Value("directionalLight.diffuse", glm::vec3(0.53f, 0.53f, 0.0f));
		m_pShaderManager->setVec3Value("directionalLight.specular", glm::vec3(0.2f, 0.0f, 0.2f));
	
		// ----------- SPOT LIGHT --------------
						
		m_pShaderManager->setBoolValue( "spotLight.bActive" , true); 
		m_pShaderManager->setBoolValue( "spotLight.bUseTexture" , true); 
		
		// Lighting the ground entrance by GREEN spotlight
		m_pShaderManager->setVec3Value("spotLight.position", glm::vec3(5.0f, 2.0f, -8.0f));
		m_pShaderManager->setVec3Value( "spotLight.direction" , glm::normalize(glm::vec3(0.0f, 5.0f, 3.0f))); 

		m_pShaderManager->setVec3Value( "spotLight.ambient" , glm::vec3(0.1f, 0.1f, 0.0f)); 
		m_pShaderManager->setVec3Value( "spotLight.diffuse" , glm::vec3(46/256, 254 / 256, 84 / 256));
		// Changed from purple (0.5, 0, 1.0) to yellow/white to keep the spot purely yellow
		m_pShaderManager->setVec3Value( "spotLight.specular" , glm::vec3(1.0f, 1.0f, 0.0f)); 

		// Attenuation coefficients (Controls distance fade-off) 
		m_pShaderManager->setFloatValue( "spotLight.constant" , 0.10f); 
		m_pShaderManager->setFloatValue( "spotLight.linear" , 0.09f); 
		m_pShaderManager->setFloatValue( "spotLight.quadratic" , 0.032f); 

		// Changed from 0.9f to 0.97f and 0.95f to create a significantly narrower, sharp cone
		m_pShaderManager->setFloatValue( "spotLight.cutOff" , glm::cos(glm::radians(12.0f))); // ~0.978f
		m_pShaderManager->setFloatValue( "spotLight.outerCutOff" , glm::cos(glm::radians(15.0f))); // ~0.965f
		
		// -----------FOUR POINT LIGHT SOURCES-------------------
		
		m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

		m_pShaderManager->setVec3Value("pointLights[0].position", 25.0f, 10.0f, 20.0f);
		// Phong light intensities (Do NOT normalize colors)
		m_pShaderManager->setVec3Value("pointLights[0].ambient", glm::vec3(0.02f, 0.02f, 0.02f)); // Set a reasonable ambient minimum
		m_pShaderManager->setVec3Value("pointLights[0].diffuse", glm::vec3(0.26f, 0.40f, 0.49f));
		m_pShaderManager->setVec3Value("pointLights[0].specular", glm::vec3(0.5f, 0.0f, 1.0f));


		m_pShaderManager->setBoolValue("pointLights[1].bActive", true);

		m_pShaderManager->setVec3Value("pointLights[1].position", 10.0f, 10.0f, 20.0f);
		// Phong light intensities (Do NOT normalize colors)
		m_pShaderManager->setVec3Value("pointLights[1].ambient", glm::vec3(0.02f, 0.02f, 0.02f)); // Set a reasonable ambient minimum
		m_pShaderManager->setVec3Value("pointLights[1].diffuse", glm::vec3(0.26f, 0.40f, 0.49f));
		m_pShaderManager->setVec3Value("pointLights[1].specular", glm::vec3(0.5f, 0.0f, 1.0f));


		m_pShaderManager->setBoolValue("pointLights[2].bActive", true);

		m_pShaderManager->setVec3Value("pointLights[2].position", -10.0f, 10.0f, 20.0f);
		// Phong light intensities (Do NOT normalize colors)
		m_pShaderManager->setVec3Value("pointLights[2].ambient", glm::vec3(0.02f, 0.02f, 0.02f)); // Set a reasonable ambient minimum
		m_pShaderManager->setVec3Value("pointLights[2].diffuse", glm::vec3(0.26f, 0.40f, 0.49f));
		m_pShaderManager->setVec3Value("pointLights[2].specular", glm::vec3(0.5f, 0.0f, 1.0f));
			

		m_pShaderManager->setBoolValue("pointLights[3].bActive", true);

		m_pShaderManager->setVec3Value("pointLights[3].position", -25.0f, 10.0f, 20.0f);
		// Phong light intensities (Do NOT normalize colors)
		m_pShaderManager->setVec3Value("pointLights[3].ambient", glm::vec3(0.02f, 0.02f, 0.02f)); // Set a reasonable ambient minimum
		m_pShaderManager->setVec3Value("pointLights[3].diffuse", glm::vec3(0.26f, 0.40f, 0.49f));
		m_pShaderManager->setVec3Value("pointLights[3].specular", glm::vec3(0.5f, 0.0f, 1.0f)); 	
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	// load the textures for the 3D scene
	LoadSceneTextures();	

	// define the materials that will be used for the objects in the 3D scene 
	DefineObjectMaterials();
	
	// add and define the light sources for the scene
	SetupSceneLights();


	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadPrismMesh();
	m_basicMeshes->LoadPyramid4Mesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;


	/*******************************************************************
	* Adding a ground holding surface
	********************************************************************/
	// set the XYZ scale for the mesh
	
	//scaleXYZ = glm::vec3(30.0f, 30.0f, 30.0f);
	scaleXYZ = glm::vec3(30.0f, 5.0f, 30.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;
	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(1, 1, 1, 1);
	//SetShaderColor(194.0 / 239.0, 200.0 / 256.0, 167.0 / 224.0, 1.0f);

	SetShaderTexture("concrete");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("cement");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/******************************************************************/

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 5.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//SetShaderColor(1, 1, 1, 1);
	
	SetShaderTexture("rock");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("cement");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	/******************************************************************/
	/******************************************************************/
	/*                       ADDING A CUBE                            */
	/******************************************************************/
	/******************************************************************/
	// set the XYZ scale for the mesh to fit requirement
	scaleXYZ = glm::vec3(40.0f, 5.0f, 10.0f);

	// set the XYZ rotation for the mesh to fit requirement
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 8.0f, -5.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//set the color values of the cube into the shader
	//SetShaderColor(241.0 / 239.0, 237.0 / 256.0, 239.0 / 256.0, 1.0f);
	
	SetShaderTexture("vertical_wood");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/******************************************************************/
	/*                       ADDING A MIDDLE CUBE                            */
	/******************************************************************/
	/******************************************************************/
	// set the XYZ scale for the mesh to fit requirement
	scaleXYZ = glm::vec3(36.0f, 2.0f, 10.0f);

	// set the XYZ rotation for the mesh to fit requirement
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 12.0f, -5.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//set the color values of the cube into the shader
	//SetShaderColor(41.0/256.0 / 239.0/256.0, 237.0 / 256.0, 239.0 / 256.0, 1.0f);

	SetShaderTexture("concrete");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("tile");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();

	/******************************************************************/
	/*                       ADDING A PRISM                            */
	/******************************************************************/
	/******************************************************************/
	// set the XYZ scale for the mesh to fit requirement
	scaleXYZ = glm::vec3(40.0f, 3.0f, 10.0f);

	// set the XYZ rotation for the mesh to fit requirement
	XrotationDegrees = -90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 15.0f, -5.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//set the color values of the cube into the shader
	//SetShaderColor(201.0/256.0 / 139.0/256.0, 237.0 / 256.0, 39.0 / 256.0, 1.0f);

	SetShaderTexture("sand");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("tile");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPrismMesh();

	/******************************************************************/
	/******************************************************************/
	/*                   ADDING NARROW LANES                           */
	/******************************************************************/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.0f, 20.0f, 2.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = -20.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(15.0f, 0.0f, 5.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//set the color values into the shader
	//SetShaderColor(120.0 / 256.0, 128 / 256.0, 255.0 / 256.0, 1.0f);

	SetShaderTexture("ground");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("cement");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.0f, 20.0f, 2.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = -10.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(7.0f, 0.0f, 5.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//set the color values into the shader
	//SetShaderColor(120.0 / 256.0, 128 / 256.0, 255.0 / 256.0, 1.0f);

	SetShaderTexture("ground");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("cement");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.0f, 20.0f, 2.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 5.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//set the color values into the shader
	//SetShaderColor(120.0 / 256.0, 128 / 256.0, 255.0 / 256.0, 1.0f);
	
	SetShaderTexture("ground");
	SetTextureUVScale(1.0, 1.0);

	SetShaderMaterial("cement");
	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.0f, 20.0f, 2.0f);
	
	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = -10.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(-10.0f, 0.0f, 5.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//set the color values into the shader
	//SetShaderColor(120.0 / 256.0, 128 / 256.0, 255.0 / 256.0, 1.0f);

	SetShaderTexture("ground");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("cement");

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	
	/******************************************************************/
	/******************************************************************/
	/*                   ADDING THIN BOX                              */
	/******************************************************************/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(10.0f, 5.0f, 12.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 5.0f, -4.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	//set the color values into the shader
	//SetShaderColor(192.0 /256.0, 192/256.0, 0.0/256.0, 1.0f);

	SetShaderTexture("barrel");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("cement");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/******************************************************************/
	/******************************************************************/
	/*                      ADDING A   CYLINDER                      */
	/******************************************************************/
	/******************************************************************/
	// Adding a cylinder aligned next to the cube
	scaleXYZ = glm::vec3(2.0f, 8.0f, 11.0f);
	positionXYZ = glm::vec3(-10.0f, 0.0f, -3.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// set the color value into the shader
	//SetShaderColor(143.0 / 205.0, 84.0 / 256.0, 49.0 / 256.0, 1.0f);

	SetShaderTexture("vintage_wood");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("wood");


	m_basicMeshes->DrawCylinderMesh();
	/******************************************************************/
	/******************************************************************/
	/*                      ADDING A   CYLINDER                      */
	/******************************************************************/
	/******************************************************************/
	// Adding a cylinder aligned next to the cube
	scaleXYZ = glm::vec3(2.0f, 8.0f, 11.0f);
	positionXYZ = glm::vec3(-20.0f, 0.0f, -3.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// set the color value into the shader
	//SetShaderColor(143.0 / 205.0, 84.0 / 256.0, 49.0 / 256.0, 1.0f);

	SetShaderTexture("vintage_wood");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("gold");

	m_basicMeshes->DrawCylinderMesh();

	/******************************************************************/
	/******************************************************************/
	/*                      ADDING A   CYLINDER                      */
	/******************************************************************/
	/******************************************************************/
	// Adding a cylinder aligned next to the cube
	scaleXYZ = glm::vec3(2.0f, 8.0f, 11.0f);
	positionXYZ = glm::vec3(20.0f, 0.0f, -3.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// set the color value into the shader
	//SetShaderColor(143.0 / 205.0, 84.0 / 256.0, 49.0 / 256.0, 1.0f);

	SetShaderTexture("vintage_wood");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("gold");

	m_basicMeshes->DrawCylinderMesh();
	/******************************************************************/
	/*                      ADDING A   CYLINDER                      */
	/******************************************************************/
	/******************************************************************/
	// Adding a cylinder aligned next to the cube
	scaleXYZ = glm::vec3(2.0f, 8.0f, 11.0f);
	positionXYZ = glm::vec3(10.0f, 0.0f, -3.0f);
	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// set the color value into the shader
	//SetShaderColor(143.0 / 205.0, 84.0 / 256.0, 49.0 / 256.0, 1.0f);

	SetShaderTexture("vintage_wood");
	SetTextureUVScale(1.0, 1.0);
	SetShaderMaterial("gold");

	m_basicMeshes->DrawCylinderMesh();

	/******************************************************************/
	/******************************************************************/
	/*                     ADDING 14 SPHERICAL LIGHT BULBS            */
	/******************************************************************/
	/******************************************************************/
	// (1) Adding a sphere aligned next to the cube

	scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f);
	positionXYZ = glm::vec3(-15.0f, 5.0f, 2.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// set the color value into the shader
	SetShaderColor(255.0 / 256.0, 255.0 / 256.0, 255.0 / 256.0, 1.0);

	m_basicMeshes->DrawSphereMesh();

	/******************************************************************/
	/******************************************************************/
	// (2) Adding a sphere aligned next to the cube

	scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f);
	positionXYZ = glm::vec3(-15.0f, 10.0f, 2.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// set the color value into the shader
	SetShaderColor(255.0 / 256.0, 255.0 / 256.0, 255.0 / 256.0, 1.0);


	m_basicMeshes->DrawSphereMesh();

	/******************************************************************/
	/******************************************************************/
	// (3) Adding a sphere aligned next to the cube

	scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f);
	positionXYZ = glm::vec3(-10.0f, 5.0f, 2.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// set the color value into the shader
	SetShaderColor(255.0 / 256.0, 255.0 / 256.0, 255.0 / 256.0, 1.0);

	
	m_basicMeshes->DrawSphereMesh();

	/******************************************************************/
	/******************************************************************/
	// (4) Adding a sphere aligned next to the cube

	scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f);
	positionXYZ = glm::vec3(-10.0f, 10.0f, 2.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// set the color value into the shader
	SetShaderColor(255.0 / 256.0, 255.0 / 256.0, 255.0 / 256.0, 1.0);


	m_basicMeshes->DrawSphereMesh();

	/******************************************************************/
	// (5) Adding a sphere aligned next to the cube

	scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f);
	positionXYZ = glm::vec3(-5.0f, 5.0f, 2.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// set the color value into the shader
	SetShaderColor(255.0 / 256.0, 255.0 / 256.0, 255.0 / 256.0, 1.0);

	m_basicMeshes->DrawSphereMesh();

	/******************************************************************/
	/******************************************************************/
	// (6) Adding a sphere aligned next to the cube

	scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f);
	positionXYZ = glm::vec3(-5.0f, 10.0f, 2.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// set the color value into the shader
	SetShaderColor(255.0 / 256.0, 255.0 / 256.0, 255.0 / 256.0, 1.0);

	m_basicMeshes->DrawSphereMesh();

	/******************************************************************/
	// (7) Adding a sphere aligned next to the cube

	scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f);
	positionXYZ = glm::vec3(0.0f, 5.0f, 2.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// set the color value into the shader
	SetShaderColor(255.0 / 256.0, 255.0 / 256.0, 255.0 / 256.0, 1.0);

	m_basicMeshes->DrawSphereMesh();
	/******************************************************************/
	// (8) Adding a sphere aligned next to the cube

	scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f);
	positionXYZ = glm::vec3(0.0f,10.0f,2.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// set the color value into the shader
	SetShaderColor(255.0 / 256.0, 255.0 / 256.0, 255.0 / 256.0, 1.0);

	m_basicMeshes->DrawSphereMesh();


	/******************************************************************/
	// (9) Adding a sphere aligned next to the cube

	scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f);
	positionXYZ = glm::vec3(5.0f, 5.0f, 2.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// set the color value into the shader
	SetShaderColor(255.0 / 256.0, 255.0 / 256.0, 255.0 / 256.0, 1.0);

	m_basicMeshes->DrawSphereMesh();
	/******************************************************************/
	// (10) Adding a sphere aligned next to the cube

	scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f);
	positionXYZ = glm::vec3(5.0f, 10.0f, 2.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// set the color value into the shader
	SetShaderColor(255.0 / 256.0, 255.0 / 256.0, 255.0 / 256.0, 1.0);

	m_basicMeshes->DrawSphereMesh();

	/******************************************************************/
	// (11) Adding a sphere aligned next to the cube

	scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f);
	positionXYZ = glm::vec3(10.0f, 5.0f, 2.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// set the color value into the shader
	SetShaderColor(255.0 / 256.0, 255.0 / 256.0, 255.0 / 256.0, 1.0);

	m_basicMeshes->DrawSphereMesh();
	/******************************************************************/
	// (12) Adding a sphere aligned next to the cube

	scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f);
	positionXYZ = glm::vec3(10.0f, 10.0f, 2.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// set the color value into the shader
	SetShaderColor(255.0 / 256.0, 255.0 / 256.0, 255.0 / 256.0, 1.0);

	m_basicMeshes->DrawSphereMesh();
	/******************************************************************/
	// (13) Adding a sphere aligned next to the cube

	scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f);
	positionXYZ = glm::vec3(15.0f, 5.0f, 2.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// set the color value into the shader
	SetShaderColor(255.0 / 256.0, 255.0 / 256.0, 255.0 / 256.0, 1.0);

	m_basicMeshes->DrawSphereMesh();
	/******************************************************************/
	// (14) Adding a sphere aligned next to the cube

	scaleXYZ = glm::vec3(0.2f, 0.2f, 0.2f);
	positionXYZ = glm::vec3(15.0f, 10.0f, 2.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// set the color value into the shader
	SetShaderColor(255.0 / 256.0, 255.0 / 256.0, 255.0 / 256.0, 1.0);

	m_basicMeshes->DrawSphereMesh();
}



